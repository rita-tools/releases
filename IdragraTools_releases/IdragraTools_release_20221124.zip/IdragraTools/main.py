from report.report_builder import ReportBuilder
from report.annual_totals_report_builder import AnnualTotalsReportBuilder


#fileName = r'C:\examples\test_img\test_irrigation_units.html'
#RB = ReportBuilder()
#with open(fileName) as f:
#	lines = f.readlines()

#text = ''.join(lines)
#res = RB.makeToc(text)
#print('res',res)

simFolder=r'C:\examples\ex_report_SIM'
outputFile = 'C:/examples/test_img/test_annual.html'
RB = AnnualTotalsReportBuilder()
outfile = RB.makeReport(simFolder,outputFile)
print(outfile)