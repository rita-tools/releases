import sys
from datetime import timedelta,date
import pandas as pd
from PyQt5 import QtWidgets, QtCore
import	matplotlib
import os
import numpy as np
import numpy.ma as ma

matplotlib.use('qt5agg')
from data_manager.chart_widget import ChartWidget

root = 'C:/idragra_code/Cropcoeff_fortran_v5/compare'
# root = 'C:/idragra_code/Cropcoeff_fortran_v5/example'
colorList = ['green','blue','red','orange']

def readSWATMeteoFile(fileName):
    initDate = None
    dataList = []
    with open(fileName) as f:
        c = 0
        for line in f:
            c += 1
            if c == 1:
                # read init time e.g. 20080101
                initDate = date(int(line[0:4]), int(line[4:6]),int(line[6:8]))
            else:
                # read value
                if float(line)==-999.0:
                    dataList.append(None)
                else:
                    dataList.append(float(line))

    # make list of dates
    dateList = [initDate+ timedelta(days=i) for i in range(0,len(dataList))]
    return dateList,dataList

def readDischFile(fileName):
    df = pd.read_csv(fileName, sep=',', usecols=['timestamp', 'discharge_m3_s-1'], na_values=-999.)
    df['timestamp'] = pd.to_datetime(df['timestamp'], format="%Y-%m-%d %H:%M:%S")
    yList = df['discharge_m3_s-1'].where(pd.notnull(df['discharge_m3_s-1']), None).to_list()
    yNew = []
    for y in yList:
        try:
            yNew.append(float(y))
        except:
            yNew.append(None)

    return df['timestamp'], yNew


def readWatLevetFile(fileName):
    df = pd.read_csv(fileName, sep=',', usecols=['timestamp', 'watlev_m'],na_values=-999.)
    df['timestamp'] = pd.to_datetime(df['timestamp'], format="%Y-%m-%d %H:%M:%S")
    yList = df['watlev_m'].where(pd.notnull(df['watlev_m']), None).to_list()
    yNew = []
    for y in yList:
        try:
            yNew.append(float(y))
        except:
            yNew.append(None)

    return df['timestamp'],yNew

def readParFile(fileName, sep = '\s* \s*'):
    df = pd.read_csv(fileName, sep)
    return df


def removePicks(data,fact = 1):
    a = np.array(data)
    meanVal = np.zeros(len(data))
    meanVal[1:-1] = 0.5*(a[0:-2]+a[2:])
    flag = np.zeros(len(a),dtype=np.bool)

    flag[1:-1] = a[1:-1]>fact*meanVal[1:-1]
    print('n. detected picks:', np.sum(flag))
    #print('flag',flag)
    a[flag] =meanVal[flag]
    #print('a:',a)
    return a.tolist()

def replaceEndLines(fileName):
    lines = []
    with open(fileName,mode='r') as f:
        lines = f.readlines()

    with open(fileName, mode='w') as f:
        for l in lines:
            newLine = l.replace('\t\n','\n').replace(' \n','\n')
            f.write(newLine)

def plotVar(selCropSeq = ['CrID_2'],
            filenameList = ['CNvalue.dat','GDD.dat','H.dat', 'LAI.dat','Sr.dat', 'Kcb.dat', 'Kcb_plain.dat'],
            outFolder = 'pheno/pheno_100',
            initDate = date(2005,1,1)):

    app = QtWidgets.QApplication(sys.argv)
    main = QtWidgets.QMainWindow()
    cw = ChartWidget(parent = main,enableConnection = False)#QtWidgets.QWidget()
    # connect

    main.setCentralWidget(cw)
    main.resize(800, 400)
    main.setWindowTitle("Plot")

    #filenameList = ['temp/brignoli/brignoli_watlev.csv']
    sharedAxes = None
    for p,f in enumerate(filenameList):
        completeFN = os.path.join(root, outFolder, f)
        print('processing', f)
        y2 = None

        df = readParFile(completeFN)
        cw.ax = cw.figure.add_subplot(len(filenameList), 1, p + 1, sharex=sharedAxes)
        x = [initDate + timedelta(days=i) for i in range(0, len(df.index))]
        if len(selCropSeq)==0:
            selCropSeq = df.keys().to_list()

        for i,k in enumerate(selCropSeq):
            y = df[k]
            cw.addTimeSerie(x, y, color='red',name=k,addToLegend = False)

        if not sharedAxes:
            sharedAxes = cw.ax

        # print(df)
        print('x',x[0:3],'...',x[-3:])
        print('y',y[0:3],'...',y[-3:])

        if y2:
            cw.addTimeSerie(x, y2,color='green')
            # save y2 to file
            newdf=pd.DataFrame({'timestamp':x,'watlev_m':y2})
            newdf.to_csv(completeFN[:-4]+'_filtered.csv',index=False)


        cw.ax.set_ylabel(os.path.basename(f))
        #axs[0].invert_yaxis()
        #cw.ax.grid(True)

    main.show()
    app.exec_()


def compare(selCropSeq='CrID_2',
            filenameList=['CNvalue.dat', 'H.dat', 'LAI.dat', 'Sr.dat', 'Kcb.dat'],
            outFolder1 = 'pheno/pheno_100',
            outFolder2 = 'pheno_v5/pheno_100',
            initDate=date(2005, 1, 1)):
    app = QtWidgets.QApplication(sys.argv)
    main = QtWidgets.QMainWindow()
    cw = ChartWidget(parent=main, enableConnection=False)  # QtWidgets.QWidget()
    # connect

    main.setCentralWidget(cw)
    main.resize(800, 400)
    main.setWindowTitle("Plot")

    # filenameList = ['temp/brignoli/brignoli_watlev.csv']
    sharedAxes = None
    for p, f in enumerate(filenameList):
        # add subplot
        cw.ax = cw.figure.add_subplot(len(filenameList), 1, p + 1, sharex=sharedAxes)

        # add first serie
        completeFN = os.path.join(root, outFolder1, f)
        print('processing', completeFN)
        replaceEndLines(completeFN)  # remove strange end-of-line
        df = readParFile(completeFN,'\t')
        x = [initDate + timedelta(days=i) for i in range(0, len(df.index))]
        y = df[selCropSeq]
        cw.addTimeSerie(x, y, color=colorList[0], name='m', addToLegend=False)

        # add second series
        completeFN = os.path.join(root, outFolder2, f)
        print('processing', completeFN)
        df = readParFile(completeFN)
        x = [initDate + timedelta(days=i) for i in range(0, len(df.index))]
        y = df[selCropSeq]
        cw.addTimeSerie(x, y, color=colorList[2], name='f', addToLegend=False)

        if not sharedAxes:
            sharedAxes = cw.ax

        cw.ax.set_ylabel(os.path.basename(f))
        # axs[0].invert_yaxis()
        # cw.ax.grid(True)

    main.show()
    app.exec_()

flag = 1
cropSeq = 'CrID_4'
if (flag):
    compare(selCropSeq=cropSeq,
                filenameList=['CNvalue.dat', 'H.dat', 'LAI.dat', 'Sr.dat', 'Kcb.dat'],
                outFolder1 = 'pheno_v4/pheno_100',
                outFolder2 = 'pheno_v5/pheno_100',
                initDate=date(2005, 1, 1))
else:
    plotVar(selCropSeq = [cropSeq],
            filenameList = ['cropid.dat','GDD.dat', 'LAI.dat', 'Kcb.dat', 'Kcb_plain.dat'],
            outFolder = 'pheno_v5/pheno_100',
            initDate = date(2005,1,1))

# filenameList = ['cropid.dat', 'CNvalue.dat', 'GDD.dat', 'H.dat', 'LAI.dat', 'Sr.dat', 'Kcb.dat', 'Kcb_plain.dat','Ky.dat'],