# -*- coding: utf-8 -*-

"""
/***************************************************************************
 IdrAgraTools
 A QGIS plugin to manage water demand simulation with IdrAgra model
 The plugin shares user interfaces and tools to manage water in irrigation districts
-------------------
		begin				: 2020-12-01
		copyright			: (C) 2020 by Enrico A. Chiaradia
		email				    : enrico.chiaradia@unimi.it
 ***************************************************************************/

/***************************************************************************
 *																		   *
 *   This program is free software you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation either version 2 of the License, or	   *
 *   (at your option) any later version.								   *
 *																		   *
 ***************************************************************************/
"""
__author__ = 'Enrico A. Chiaradia'
__date__ = '2020-12-01'
__copyright__ = '(C) 2020 by Enrico A. Chiaradia'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'

from numpy import ones, size, sum, NaN, array, zeros, pi, cos, logical_and, cumsum, sin, arccos, tan, min, mean, arcsin, \
	diff, concatenate, where
from datetime import date,timedelta

def findSowingDate(Tave,DoY,currentDayIndex,timeSpan,minSowingDate,sowingDelay,T_sowing,isWinterCrop):
	# return the index of the first available day for seeding
	sowingDateIdx = -1
	# test current days window
	testSpan = zeros(size(Tave))
	testSpan[currentDayIndex:currentDayIndex+timeSpan] =1

	# test sowing window
	testSowingWindow = logical_and(DoY>=minSowingDate,DoY<=minSowingDate+sowingDelay)
	testSowingWindow = logical_and(testSowingWindow,testSpan)

	if sum(testSowingWindow) == 0:
		# no available dates in serie
		return sowingDateIdx

	# test temperature Tave > T_sowing and sowing window
	testT = logical_and(Tave>T_sowing,testSowingWindow)
	# adjust sowing date
	if sum(testT)==0:
		if isWinterCrop: sowingDate = minSowingDate
		else: sowingDate = minSowingDate+sowingDelay # summer crop
		rows = where(DoY == sowingDate)
		sowingDateIdx = rows[0][0]
	else:
		# find the first element in array
		rows = where(testT == 1)
		sowingDateIdx = rows[0][0]

	return sowingDateIdx

def calculateDLH(DoY, wsLat):
	#### Computes daylight hours
	phi = pi / 180 * wsLat  # latitude [rad],          FAO56: eq. 22 pag 46
	delta = 0.409 * sin(2 * pi / 365 * DoY - 1.39)  # solar declination,       FAO56: eq. 24 pag 46
	omega_s = arccos(-tan(phi) * tan(delta))  # sunset hour angle [rad], FAO56: eq. 25 pag 46
	DLH = 24 / pi * omega_s  # daylight hours,          FAO56: eq. 34 pag 48
	return DLH

def calculateGDD(Tmax, Tmin, Tdaybase, Tcutoff):
	#### New version: sine wave
	Tave = mean([Tmax,Tmin],axis=0)
	T_GDD_low = zeros(size(Tmax))
	T_GDD_up = zeros(size(Tmax))
	W = (Tmax - Tmin) / 2
	i1 = logical_and(Tmin >= Tdaybase, Tmax <= Tcutoff)
	i2 = logical_and(logical_and(Tmin < Tdaybase, Tmax <= Tcutoff), Tmax > Tdaybase)
	i3 = logical_and(logical_and(Tmin >= Tdaybase, Tmax > Tcutoff), Tmin < Tcutoff)
	i4 = logical_and(Tmin < Tdaybase, Tmax > Tcutoff)
	i5 = Tmin >= Tcutoff
	# i6      both Tmax and T min are < Tcutoff -> no heat units accumulation (matrix already initialized to zero)

	# case 1
	if sum(i1) > 0:
		T_GDD_low[i1] = Tave[i1] - Tdaybase

	# case 2
	if sum(i2) > 0:
		theta2 = arcsin((Tdaybase - Tave[i2])/ W[i2])
		T_GDD_low[i2] = ((Tave[i2] - Tdaybase)* (pi / 2 - theta2) + W[i2]* cos(theta2))/ pi

	# case 3
	if sum(i3) > 0:
		phi3 = arcsin((Tcutoff - Tave[i3]) / W[i3])
		T_GDD_low[i3] = Tave[i3] - Tdaybase
		T_GDD_up[i3] = ((Tave[i3] - Tcutoff) * (pi / 2 - phi3) + W[i3]* cos(phi3))/ pi

	# case 4
	if sum(i4) > 0:
		theta4 = arcsin((Tdaybase - Tave[i4])/ W[i4])
		phi4 = arcsin((Tcutoff - Tave[i4])/ W[i4])
		T_GDD_low[i4] = ((Tave[i4] - Tdaybase)* (pi / 2 - theta4) + W[i4]* cos(theta4))/ pi
		T_GDD_up[i4] = ((Tave[i4] - Tcutoff) * (pi / 2 - phi4) + W[i4]* cos(phi4))/ pi
	# case 5
	if sum(i5) > 0:
		T_GDD_low[i5] = Tcutoff - Tdaybase

	# calcolate GDD
	T_GDD = T_GDD_low - T_GDD_up
	return T_GDD

def vernalization(Tave, Tv_min, Tv_max, Vslope, Vstart, Vend, VFmin):
	#### Vernalization
	Veff = zeros(size(Tave))  # vernalization contribution of the day
	# Calculate vernalization contribution of the day
	Veff[Tave < (Tv_min - Vslope)] = 0  # PhD Thesis Anna Borghi: eq i-81 page 172
	i = logical_and(Tave >= (Tv_min - Vslope), Tave < Tv_min)  # PhD Thesis Anna Borghi: eq i-81 page 172
	Veff[i] = 1 - (Tv_min - Tave[i]) / Vslope  # PhD Thesis Anna Borghi: eq i-81 page 172
	Veff[logical_and(Tave >= Tv_min, Tave < Tv_max)] = 1  # PhD Thesis Anna Borghi: eq i-81 page 172
	ii = logical_and(Tave >= Tv_max, Tave < (Tv_max + Vslope))  # PhD Thesis Anna Borghi: eq i-81 page 172
	Veff[ii] = 1 - (Tave[ii] - Tv_max) / Vslope  # PhD Thesis Anna Borghi: eq i-81 page 172
	Veff[Tave >= (Tv_max + Vslope)] = 0  # PhD Thesis Anna Borghi: eq i-81 page 172
	# Calculate  sum of accumulated vernalization days
	VDsum = cumsum(Veff)  # sum of the currently accumulated vernalization days
	# Calculate  vernalization factor
	VF = VFmin + ((1 - VFmin) * (VDsum - Vstart)) / (Vend - Vstart)  # vernalization factor (PhD Thesis Anna Borghi: eq i-81 page 172)
	VF[VDsum < Vstart] = 1
	VF[VDsum > Vend] = 1
	return VF

def photoperiod(DLH, ph_r, daylength_if, daylength_ins):
	#### Photoperiod
	PF = ones(size(DLH))  # photoperiod factor
	if ph_r == 1:  # Long-day plants, PhD Thesis Anna Borghi: eq i-82 page 172
		PF[DLH < daylength_if] = 0
		PF[DLH > daylength_ins] = 1
		threshInd = logical_and(DLH >= daylength_if, DLH <= daylength_ins)
		PF[threshInd] = (DLH[threshInd] - daylength_if) / (daylength_ins - daylength_if)
	elif ph_r == 2:  # Short-day plants, PhD Thesis Anna Borghi: eq i-83 page 172 (Corrected!!! see http://modeling.bsyse.wsu.edu/CS_Suite/cropsyst/manual/simulation/crop/photoperiod.htm)
		PF[DLH > daylength_if] = 0
		PF[DLH < daylength_ins] = 1 #TODO: questa condizione annulla la precedente se daylength_ins > daylength_if. Aggiugere check?
		threshInd = logical_and(DLH >= daylength_ins, DLH < daylength_if)
		PF[threshInd] = (daylength_if - DLH[threshInd]) / (daylength_if - daylength_ins)
	else:
		# do nothing
		pass

	return PF

def calculateDoY(startDay,nOfDay):
	testDay = startDay
	endDay = startDay+timedelta(days=nOfDay)
	DoY = []
	dateList = []
	while testDay < endDay:
		DoY.append(int(testDay.strftime('%j')))
		dateList.append(testDay)
		testDay += timedelta(days=1)

	return array(dateList),array(DoY)

def cumSumReset(values,resetAt = 0):
	# TODO: not the most efficient way
	cumValue = 0.0
	cumValueList = []
	for v in values.tolist():
		if v==resetAt:
			cumValue = 0.0
		else:
			cumValue += v

		cumValueList.append(cumValue)

	return array(cumValueList)




def computeGDD(wsLat, startDay, Tmax, Tmin, Tdaybase, Tcutoff, Vern, Tv_min, Tv_max, Vslope, Vstart, Vend, VFmin, ph_r, daylength_if, daylength_ins):
	nOfDay = len(Tmax)
	days, DoY = calculateDoY(startDay,nOfDay)
	#print('DoY',DoY)

	Tave = 0.5*(Tmax+Tmin)

	DLH = calculateDLH(DoY, wsLat)
	#print('DLH',DLH)

	T_GDD = calculateGDD(Tmax, Tmin, Tdaybase, Tcutoff)
	#print('T_GDD', T_GDD)

	VF = ones(size(Tmax))
	if Vern:
		VF = vernalization(Tave, Tv_min, Tv_max, Vslope, Vstart, Vend, VFmin)

	#print('VF', VF)


	PF = ones(size(Tmax))
	if ph_r:
		PF = photoperiod(DLH, ph_r, daylength_if, daylength_ins)

	T_GDD_corr = T_GDD * min([VF, PF],axis=0)
	#print('PF', PF)
	#### Computes GDD considering both VF and PF
	GDD_cum = cumSumReset(T_GDD_corr)  # PhD Thesis Anna Borghi: eq i-85 page 173

	return days, DoY,DLH,T_GDD,T_GDD_corr,VF,PF,GDD_cum

def computeCropSeq(wsLat, startDay, Tmax, Tmin, cropSeq):

	nOfDay = len(Tmax)
	days, DoY = calculateDoY(startDay,nOfDay)
	#print('DoY',DoY)
	#make a list of crops in field
	cropsOverYear = zeros(size(Tmax))

	Tave = 0.5*(Tmax+Tmin)

	DLH = calculateDLH(DoY, wsLat)
	#print('DLH',DLH)

	currentDayIndex = 0
	harvestIndex = 0
	timeSpan = 366

	cropSeqIter = iter(cropSeq)

	while currentDayIndex<=nOfDay:
		# get the next crop in the list
		cr = next(cropSeqIter, None)
		if cr is None:
			# reloop
			cropSeqIter = iter(cropSeq)
			cr = next(cropSeqIter, None)

		#print('process:',cr['id'],'-',cr['name'])

		#update timeSpan
		if nOfDay-currentDayIndex<timeSpan:
			timeSpan = nOfDay-currentDayIndex

		# find sowing index
		sowIndex = findSowingDate(Tave, DoY, currentDayIndex,timeSpan, cr['minSowingDate'], cr['sowingDelay'], cr['T_sowing'], cr['Vern'])
		if sowIndex<0:
			# TODO: not sure which is the currect span
			currentDayIndex += cr['CropsOverlap']
		else:
			# TODO: check overlapping crop
			print('sowing crop',cr['name'],'at sowIndex:', sowIndex,'DoY',DoY[sowIndex],'date',days[sowIndex])
			# make a subset of variable
			Tmax_sub = Tmax[sowIndex:sowIndex+timeSpan]
			Tmin_sub = Tmin[sowIndex:sowIndex + timeSpan]
			Tave_sub = Tave[sowIndex:sowIndex + timeSpan]
			DLH_sub = DLH[sowIndex:sowIndex + timeSpan]

			T_GDD_sub = calculateGDD(Tmax_sub, Tmin_sub, cr['Tdaybase'], cr['Tcutoff'])

			VF_sub = ones(size(Tmax_sub))
			if cr['Vern']:
				VF_sub = vernalization(Tave, cr['Tv_min'], cr['Tv_max'], cr['Vslope'], cr['Vstart'], cr['Vend'], cr['VFmin'])

			PF_sub = ones(size(Tmax_sub))
			if cr['ph_r']:
				PF_sub = photoperiod(DLH_sub, cr['ph_r'], cr['daylength_if'], cr['daylength_ins'])

			T_GDD_corr_sub = T_GDD_sub * min([VF_sub, PF_sub],axis=0)
			#print('PF', PF)
			#### Computes GDD considering both VF and PF
			GDD_cum_sub = cumSumReset(T_GDD_corr_sub)  # PhD Thesis Anna Borghi: eq i-85 page 173
			if max(GDD_cum_sub)>cr['maxGDD']:
				# enough thermal resources to finish the crop
				rows = where(GDD_cum_sub>cr['maxGDD'])
				harvestIndex = sowIndex +rows[0][0]
				# set the period to crop
				cropsOverYear[sowIndex:harvestIndex]=cr['id']

				# update currentDayIndex
				currentDayIndex = harvestIndex+cr['CropsOverlap']
			else:
				currentDayIndex += cr['CropsOverlap']

	return days, DoY,cropsOverYear



def test1():
	import pandas as pd
	import matplotlib

	matplotlib.use('qt5agg')
	import matplotlib.pyplot as plt


	# open table
	csvFile = 'C:/test_landriano/test11_SIM/meteodata/100.dat'
	df = pd.read_csv(csvFile, sep='\s* \s*',usecols = ['T_max','T_min'],skiprows = 3, engine='python')

	# calculate
	cropTbase = 10.0
	cropTcutoff = 25.
	# 49.5
	days, DoY,DLH,T_GDD,T_GDD_corr,VF,PF,GDD_cum, = computeGDD(wsLat = 49.5, startDay = date(2000,1,1),
											  Tmax = df['T_max'], Tmin  = df['T_min'],
											  Tdaybase = cropTbase, Tcutoff = cropTcutoff,
											  Vern = 1, Tv_min = 3, Tv_max = 10, Vslope = 7, Vstart= 10, Vend=50, VFmin =0,
											  ph_r = 0, daylength_if=8, daylength_ins=20)
	# plot

	fig, axs = plt.subplots(5, 1)
	axs[0].plot(days,df['T_max'],label='T max')
	axs[0].plot(days, df['T_min'], label='T min')
	axs[0].plot(days, zeros(size(days))+cropTbase, label='T base')
	axs[0].plot(days, zeros(size(days)) + cropTcutoff, label='T cutoff')

	#axs[0].hlines(cropTbase,1,365,label='T base')
	#axs[0].hlines(cropTcutoff,1,365, label='T cutoff')
	axs[0].legend()
	axs[0].set_xlabel('days')
	axs[0].set_ylabel('T')
	axs[0].grid(True)

	axs[1].plot(days,DLH)
	axs[1].set_xlabel('days')
	axs[1].set_ylabel('DLH')
	axs[1].grid(True)
	axs[1].set_ylim([0,24])

	axs[2].plot(days, T_GDD, label='T_GDD')
	axs[2].plot(days, T_GDD_corr,label='T_GDD_corr')
	axs[2].legend()
	axs[2].set_xlabel('days')
	axs[2].set_ylabel('T_GDD')
	axs[2].grid(True)

	axs[3].plot(days, VF,label='VF')
	axs[3].plot(days, PF,label='PF')
	axs[3].legend()
	axs[3].set_xlabel('days')
	axs[3].set_ylabel('VF,PF')
	axs[3].grid(True)
	axs[3].set_ylim([0, 1.1])

	axs[4].plot(days, GDD_cum)
	axs[4].set_xlabel('days')
	axs[4].set_ylabel('GDD_cum')
	axs[4].grid(True)

	fig.tight_layout()
	plt.show()

def test2():
	import pandas as pd
	import matplotlib

	matplotlib.use('qt5agg')
	import matplotlib.pyplot as plt

	# open table
	csvFile = 'C:/test_landriano/test11_SIM/meteodata/100.dat'
	df = pd.read_csv(csvFile, sep='\s* \s*', usecols=['T_max', 'T_min'], skiprows=3, engine='python')

	cropsList = [{'id':1,'name':'mais600',
				 'minSowingDate':91, 'sowingDelay':14, 'T_sowing':9,
				 'Vern':0,'Tdaybase':9, 'Tcutoff':30,'Tv_min':3, 'Tv_max':10, 'Vslope':7, 'Vstart':10, 'Vend':50, 'VFmin':0,
				 'ph_r':0, 'daylength_if':8, 'daylength_ins':20,
				 'maxGDD':1720,'CropsOverlap':7},
				 {'id': 2, 'name': 'mais600_bis',
				  'minSowingDate': 20, 'sowingDelay': 90, 'T_sowing': 9,
				  'Vern': 0, 'Tdaybase': 9, 'Tcutoff': 30, 'Tv_min': 3, 'Tv_max': 10, 'Vslope': 7, 'Vstart': 10,
				  'Vend': 50, 'VFmin': 0,
				  'ph_r': 0, 'daylength_if': 8, 'daylength_ins': 20,
				  'maxGDD': 1720, 'CropsOverlap': 7}
				]

	days, DoY,cropsOverYear = computeCropSeq(wsLat = 49.5, startDay = date(2000,1,1),
											  Tmax = df['T_max'], Tmin  = df['T_min'], cropSeq=cropsList)

	fig, axs = plt.subplots(2, 1)
	axs[0].plot(days, df['T_max'], label='T max')
	axs[0].plot(days, df['T_min'], label='T min')

	axs[1].plot(days, cropsOverYear, label='crop id')

	fig.tight_layout()
	plt.show()

if __name__ == '__main__':
	test2()
