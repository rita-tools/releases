# -*- coding: utf-8 -*-

"""
***************************************************************************
*                                                                         *
*   This program is free software; you can redistribute it and/or modify  *
*   it under the terms of the GNU General Public License as published by  *
*   the Free Software Foundation; either version 2 of the License, or     *
*   (at your option) any later version.                                   *
*                                                                         *
***************************************************************************
"""

from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (QgsProcessing,
                       QgsFeatureSink,
                       QgsProcessingException,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink, QgsProcessingParameterField, QgsFeatureRequest,
                       QgsProcessingParameterNumber, QgsFields, QgsField, QgsWkbTypes, QgsFeature, QgsGeometry,
                       QgsPointXY, QgsPoint)
from qgis import processing


class ProgressiveBufferAlgorithm(QgsProcessingAlgorithm):
    """
    This is an example algorithm that takes a vector layer and
    creates a new identical one.

    It is meant to be used as an example of how to create your own
    algorithms and explain methods and variables used to do it. An
    algorithm like this will be available in all elements, and there
    is not need for additional work.

    All Processing algorithms should extend the QgsProcessingAlgorithm
    class.
    """

    # Constants used to refer to parameters and outputs. They will be
    # used when calling the algorithm from another algorithm, or when
    # calling from the QGIS console.

    INPUTPOINT = 'INPUT_POINT'
    IDFIELD = 'ID_FIELD'
    SORTFIELD = 'SORT_FIELD'
    BUFFERSIZE = 'BUFFER_SIZE'
    RAWOUTPUT = 'RAW_OUTPUT'
    SNAKEOUTPUT = 'SNAKE_OUTPUT'
    FINALOUTPUT = 'FINAL_OUTPUT'
    

    def tr(self, string):
        """
        Returns a translatable string with the self.tr() function.
        """
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return ProgressiveBufferAlgorithm()

    def name(self):
        """
        Returns the algorithm name, used for identifying the algorithm. This
        string should be fixed for the algorithm, and must not be localised.
        The name should be unique within each provider. Names should contain
        lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'progressive_buffer'

    def displayName(self):
        """
        Returns the translated algorithm name, which should be used for any
        user-visible display of the algorithm name.
        """
        return self.tr('Progressive buffer')

    def group(self):
        """
        Returns the name of the group this algorithm belongs to. This string
        should be localised.
        """
        return self.tr('Test')

    def groupId(self):
        """
        Returns the unique ID of the group this algorithm belongs to. This
        string should be fixed for the algorithm, and must not be localised.
        The group id should be unique within each provider. Group id should
        contain lowercase alphanumeric characters only and no spaces or other
        formatting characters.
        """
        return 'test'

    def shortHelpString(self):
        """
        Returns a localised short helper string for the algorithm. This string
        should provide a basic description about what the algorithm does and the
        parameters and outputs associated with it..
        """
        return self.tr("Create width defined polygon along path")

    def initAlgorithm(self, config=None):
        """
        Here we define the inputs and output of the algorithm, along
        with some other properties.
        """

        self.addParameter(
            QgsProcessingParameterFeatureSource(
                self.INPUTPOINT,
                self.tr('Input point layer'),
                [QgsProcessing.TypeVectorPoint]
            )
        )
        
        self.addParameter(
            QgsProcessingParameterField(
            self.IDFIELD, self.tr('Id field'), None,
                self.INPUTPOINT
            )
        )

        self.addParameter(
            QgsProcessingParameterField(
            self.SORTFIELD, self.tr('Sort by field'), None,
                self.INPUTPOINT
            )
        )

        self.addParameter(QgsProcessingParameterNumber(self.BUFFERSIZE, self.tr('Buffer size'),QgsProcessingParameterNumber.Double))

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.RAWOUTPUT,
                self.tr('Raw output layer')
            )
        )
        
        
        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.SNAKEOUTPUT,
                self.tr('Snake output layer')
            )
        )

        self.addParameter(
            QgsProcessingParameterFeatureSink(
                self.FINALOUTPUT,
                self.tr('Final output layer')
            )
        )

    def processAlgorithm(self, parameters, context, feedback):
        """
        Here is where the processing itself takes place.
        """

        # Retrieve the feature source and sink. The 'dest_id' variable is used
        # to uniquely identify the feature sink, and must be included in the
        # dictionary returned by the processAlgorithm function.
        sourcePt = self.parameterAsSource(
            parameters,
            self.INPUTPOINT,
            context
        )

        # If source was not found, throw an exception to indicate that the algorithm
        # encountered a fatal error. The exception text can be any string, but in this
        # case we use the pre-built invalidSourceError method to return a standard
        # helper text for when a source cannot be evaluated
        if sourcePt is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUTPOINT))

        idFld = self.parameterAsFields(parameters, self.IDFIELD, context)[0]
        sortFld = self.parameterAsFields(parameters, self.SORTFIELD, context)[0]
        bufferSize = self.parameterAsDouble(parameters, self.BUFFERSIZE, context)

        fldList = QgsFields()
        for field in sourcePt.fields():
            if (field.name() == idFld): fldList.append(field)
            if (field.name() == sortFld): fldList.append(field)

        # add other fields
        fldList.append(QgsField('dist', QVariant.Double))
        fldList.append(QgsField('areacalc', QVariant.Double))
        fldList.append(QgsField('areateo', QVariant.Double))
        fldList.append(QgsField('arearat', QVariant.Double))

        (sinkRaw, destIdRaw) = self.parameterAsSink(
            parameters,
            self.RAWOUTPUT,
            context,
            fldList,
            QgsWkbTypes.Polygon,
            sourcePt.sourceCrs()
        )

        (sinkFinal, destIdFinal) = self.parameterAsSink(
            parameters,
            self.FINALOUTPUT,
            context,
            fldList,
            QgsWkbTypes.Polygon,
            sourcePt.sourceCrs()
        )


        (sinkSnake, destIdSnake) = self.parameterAsSink(
            parameters,
            self.SNAKEOUTPUT,
            context,
            fldList,
            QgsWkbTypes.Polygon,
            sourcePt.sourceCrs()
        )

        # loop in point and get x,y and id
        request = QgsFeatureRequest()

        # set order by field
        clause = QgsFeatureRequest.OrderByClause(sortFld, ascending=True)
        orderby = QgsFeatureRequest.OrderBy([clause])
        request.setOrderBy(orderby)

        features = sourcePt.getFeatures(request)

        xs = []
        ys = []
        ids = []
        sortValues = []
        for feature in features:
            pt = feature.geometry().asPoint()
            xs.append(pt.x())
            ys.append(pt.y())
            ids.append(feature[idFld])
            sortValues.append(feature[sortFld])

        feedback.pushInfo('sort from %s to %s'%(str(ids[0]),str(ids[-1])))

        nOfpoints = len(ids)

        snakePoly = None

        for i in range(0,nOfpoints-1):
            startPtX = xs[i]
            startPtY = ys[i]
            endPtX = xs[i + 1]
            endPtY = ys[i + 1]
            refId = ids[i + 1]
            refVal = sortValues[i+1]
            follPtX = None #xs[i + 2]
            follPtY = None #ys[i + 2]

            # make the raw polygon
            rawPoly = self.makeRawPoly(startPtX,startPtY,endPtX,endPtY,follPtX,follPtY, bufferSize)
            dist = self.makeEuDistance(startPtX, startPtY, endPtX, endPtY)

            # make intersection with snake and row polygon = final polygon
            if snakePoly:
                finalPoly = rawPoly.difference(snakePoly)
                # add final polygon to snake polygon
                snakePoly = snakePoly.combine(finalPoly)
            else:
                finalPoly = rawPoly
                snakePoly = rawPoly


            # Add a feature in the sink
            rawFeature = QgsFeature(fldList)
            rawFeature.setGeometry(rawPoly)
            rawFeature[idFld] = refId
            rawFeature[sortFld] = refVal
            rawFeature['dist'] = dist
            rawFeature['areacalc'] = rawPoly.area()
            rawFeature['areateo'] = dist*(2*bufferSize)
            rawFeature['arearat'] = rawFeature['areateo']/rawFeature['areacalc']

            sinkRaw.addFeature(rawFeature, QgsFeatureSink.FastInsert)

            finalFeature = QgsFeature(fldList)
            finalFeature.setGeometry(finalPoly)
            finalFeature[idFld] = refId
            finalFeature[sortFld] = refVal
            finalFeature['dist'] = dist
            finalFeature['areacalc'] = finalPoly.area()
            finalFeature['areateo'] = dist * (2 * bufferSize)
            if finalFeature['areacalc']>0:
                finalFeature['arearat'] = finalFeature['areateo'] / finalFeature['areacalc']
            else:
                finalFeature['arearat'] = 0

            sinkFinal.addFeature(finalFeature, QgsFeatureSink.FastInsert)

            feedback.setProgress(100.0 * i / (nOfpoints-2))

        # finally populate shake
        snakeFeature = QgsFeature(fldList)
        snakeFeature.setGeometry(snakePoly)
        snakeFeature[idFld] = 1
        sinkSnake.addFeature(snakeFeature, QgsFeatureSink.FastInsert)

        return {self.RAWOUTPUT: destIdRaw, self.FINALOUTPUT: destIdFinal, self.SNAKEOUTPUT: destIdSnake}

    def makeRawPoly(self,startPtX,startPtY,endPtX,endPtY,follPtX,follPtY, bufferSize):
        PointList = [QgsPoint(startPtX,startPtY),QgsPoint(endPtX,endPtY)]
        geom = QgsGeometry.fromPolyline(PointList)
        geom = geom.buffer(bufferSize,0)
        return geom

    def makeEuDistance(self,startPtX,startPtY,endPtX,endPtY):
        dist = QgsPoint(startPtX,startPtY).distance(QgsPoint(endPtX,endPtY))
        return dist