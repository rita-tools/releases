# -*- coding: utf-8 -*-

"""
/***************************************************************************
 IdrAgraTools
 A QGIS plugin to manage water demand simulation with IdrAgra model
 The plugin shares user interfaces and tools to manage water in irrigation districts
-------------------
		begin				: 2020-12-01
		copyright			: (C) 2020 by Enrico A. Chiaradia
		email				    : enrico.chiaradia@unimi.it
 ***************************************************************************/

/***************************************************************************
 *																		   *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or	   *
 *   (at your option) any later version.								   *
 *																		   *
 ***************************************************************************/
"""
__author__ = 'Enrico A. Chiaradia'
__date__ = '2020-12-01'
__copyright__ = '(C) 2020 by Enrico A. Chiaradia'

# This will get replaced with a git SHA1 when you do a git archive

__revision__ = '$Format:%H$'


from PyQt5.QtCore import QObject
import pandas as pd

class Node(QObject):
    def __init__(self, parent=None, id = None, nodeType = None, numDay =0):
        QObject.__init__(self, parent)
        self.id = str(id)
        self.nodeType = nodeType
        self.upStreamNodes = []
        self.upStreamRatio = []
        self.upStreamLosses = []
        self.downStreamNodes = []
        self.downStreamRatio = []
        self.downStreamLosses = []

        self.upStreamCumRatio = -1
        self.downStreamCumRatio = -1

        self.qnom = 0.

        # weigth to distribute water to upsteram source
        self.QIrrW = 0.
        self.comeFromIrr = False
        self.QPrivateW = 1.
        self.comeFromPrivate = False # store node state along path to Private source
        self.QCrsW = 1.
        self.QCrsCumW = 1.

        self.Qirr = pd.DataFrame([0.]*numDay,dtype=float)
        self.Qcrs = pd.DataFrame([0.]*numDay,dtype=float)
        self.Qprivate = pd.DataFrame([0.]*numDay,dtype=float)

    def setQnom(self,val):
        self.qnom = val

    def addUpStreamNode(self,nodeId, flowRatio=1, infLosses = 0):
        self.upStreamNodes.append(nodeId)
        self.upStreamRatio.append(flowRatio)
        self.upStreamLosses.append(infLosses)

    def addDownStreamNode(self,nodeId, flowRatio=1, infLosses = 0):
        self.downStreamNodes.append(nodeId)
        self.downStreamRatio.append(flowRatio)
        self.downStreamLosses.append(infLosses)

    def updateUpStreamCumRatio(self, flowRatio,infLosses):
        if self.upStreamCumRatio: self.upStreamCumRatio*=flowRatio*(1-infLosses)
        else: self.upStreamCumRatio=flowRatio*(1-infLosses)

    def updateDownStreamCumRatio(self, flowRatio,infLosses):
        if self.downStreamCumRatio: self.downStreamCumRatio*=flowRatio*(1-infLosses)
        else: self.downStreamCumRatio=flowRatio*(1-infLosses)

    def updateQIrrWeigth(self,nodeDict):
        #print(self.downStreamNodes)
        self.comeFromIrr = True
        for nodeId,flowRatio,infLosses in zip(self.downStreamNodes,self.downStreamRatio,self.downStreamLosses):
            node = nodeDict[str(nodeId)]
            node.qnom += self.qnom # transfer all the discharge
            node.QIrrW = flowRatio*(1-infLosses)
            # call following nodes
            node.updateQIrrWeigth(nodeDict)

    def updateQPrivateWeigth(self,nodeDict):
        #print('node %s: %s'%(self.id,self.QPrivateW))
        self.comeFromPrivate = True
        for nodeId,flowRatio,infLosses in zip(self.downStreamNodes,self.downStreamRatio,self.downStreamLosses):
            node = nodeDict[str(nodeId)]
            node.QPrivateW *= flowRatio*(1-infLosses)
            # call following nodes
            node.updateQPrivateWeigth(nodeDict)


    def updateQCrsWeigth(self, nodeDict, irrDistrEff):
        for nodeId,flowRatio,infLosses in zip(self.downStreamNodes,self.downStreamRatio,self.downStreamLosses):
            node = nodeDict[str(nodeId)]
            distrEff = 1. # by default
            if node.nodeType in [3]: distrEff = irrDistrEff[node.id] # compute also internal district eff

            node.QCrsW = flowRatio * (1 - infLosses) * distrEff
            self.QCrsCumW += node.updateQCrsWeigth(nodeDict, irrDistrEff)

        return self.QCrsCumW

    def upstreamDistributeFlow(self,nodeDict):
        for nodeId in self.upStreamNodes:
            node = nodeDict[str(nodeId)]

            if node.comeFromIrr:
                if self.QIrrW: upStreamFlowRatio = 1/self.QIrrW
                else: upStreamFlowRatio = 0.

                print('self id', self.id, 'node id', nodeId, 'self Q', self.qnom, 'node Q', node.qnom,'self QIrrW',self.QIrrW, 'upStreamFlowRatio',
                      upStreamFlowRatio)

                if node.Qirr is None: node.Qirr = self.Qirr*(node.qnom/self.qnom)*upStreamFlowRatio
                else: node.Qirr += self.Qirr*(node.qnom/self.qnom)*upStreamFlowRatio

            # if self.QPrivateW: upStreamFlowRatio =  node.QPrivateW/self.QPrivateW
            # else: upStreamFlowRatio = 0.
            if node.comeFromPrivate:
                upStreamFlowRatio = self.QPrivateW
                #print('upStreamFlowRatio',upStreamFlowRatio)
                if node.Qprivate is None: node.Qprivate = self.Qprivate/upStreamFlowRatio
                else: node.Qprivate += self.Qprivate/upStreamFlowRatio

            # call following upstream nodes
            node.upstreamDistributeFlow(nodeDict)

    def downstreamDistributeFlow(self,nodeDict,QCrsDF):
        print('Test node %s', self.id)
        if self.id in list(QCrsDF.columns):
            # if the current node is a cr source
            self.Qcrs = pd.DataFrame(QCrsDF[self.id])
            #self.Qcrs.rename(columns={self.id: '0'}, inplace=True)
        else:
            # loop in upstream nodes list and get discharges
            print('it is a other')
            for n,nodeId in enumerate(self.upStreamNodes):
                node = nodeDict[str(nodeId)]
                node.QCrsCumW *= self.QCrsCumW*node.QCrsW
                print('node id', nodeId, 'w', node.QCrsW)
                out = node.downstreamDistributeFlow(nodeDict, QCrsDF)*node.QCrsCumW
                print('self.Qcrs\n',self.Qcrs)
                print('out\n', out)
                self.Qcrs.iloc[:, 0] = self.Qcrs.iloc[:, 0]+ out.iloc[:, 0]

        return self.Qcrs

class NetworkAnalyst(QObject):
    def __init__(self,progress=None, tr=None, parent=None):
        QObject.__init__(self, parent)
        self.progress = progress
        self.tr = tr
        self.nodeDict = {}

    def addNode(self, node, replace = True):
        if ((not replace) and (node.id in list(self.nodeDict.keys()))): return

        self.nodeDict[node.id]= node

    def buildNetwork(self, nodeDF, linkDF, numOfDay):
        # build the network
        for n, node in nodeDF.iterrows():
            #print('add node',node['id'])
            newNode = Node(self, int(node['id']), int(node['node_type']), numOfDay)
            newNode.setQnom(node['q_sum'])
            #print('newNode id', newNode.id)
            # filter all links that have this node as upStream
            linkSel = linkDF[linkDF['outlet_node'].isin([node['id']])]
            for l, link in linkSel.iterrows():
                #print('add upstream node', link['inlet_node'])
                newNode.addUpStreamNode(int(link['inlet_node']),link['flow_rate'],link['inf_losses'])


            # filter all links that have this node as downStream
            linkSel = linkDF[linkDF['inlet_node'].isin([node['id']])]
            for l, link in linkSel.iterrows():
                #print('add downstream node', link['outlet_node'])
                newNode.addDownStreamNode(int(link['outlet_node']), link['flow_rate'], link['inf_losses'])

            self.addNode(newNode, False)

    def updateDischargeWeights(self,QirrDF,QPrivateDF,QCrsDF,distrEffDict):
        # update discharges based weights
        watDistrList = []

        for id, node in self.nodeDict.items():
            if node.nodeType in [11]: # monitored sources
                #node.QIrrW = node.qnom
                node.updateQIrrWeigth(self.nodeDict)
            if node.nodeType in [13]: # CR sources
                totEff = node.updateQCrsWeigth(self.nodeDict,distrEffDict)
                if node.id in list(QCrsDF.columns): node.QCrsW = totEff*QCrsDF[node.id]
            elif node.nodeType in [14]: # private sources
                node.QPrivateW = 1.
                node.updateQPrivateWeigth(self.nodeDict)
            elif node.nodeType in [3]: # water distributor, populate
                # get irrigation district distr_eff
                if ('Source_' + str(node.id)) in list(QirrDF.columns):
                    # node is fed by monitored source
                    node.Qirr = pd.DataFrame(QirrDF['Source_'+str(node.id)].values.tolist())
                    # update

                if ('Source_' + str(node.id)) in list(QPrivateDF.columns):
                    # node is fed by private source
                    node.Qprivate = pd.DataFrame(QPrivateDF['Source_' + str(node.id)].values.tolist())

                # store water distributors
                watDistrList.append(node.id)
            else:
                pass

        return watDistrList

    def calculateFlowAtNodes(self,watDistrList,QCrsDF):
        # loop in water distributor nodes and update collected discharges
        for wd in watDistrList:
            # get node
            node = self.nodeDict[wd]
            node.upstreamDistributeFlow(self.nodeDict)
            node.downstreamDistributeFlow(self.nodeDict,QCrsDF)


    def getFlowAtNodes(self,dates):
        QirrAll = []
        QcrsAll = []
        QprivateAll = []
        IdAll = []
        datesAll = []

        for id,node in self.nodeDict.items():
            QirrAll += node.Qirr.iloc[:, 0].values.tolist()
            QcrsAll += node.Qcrs.iloc[:, 0].values.tolist()
            QprivateAll += node.Qprivate.iloc[:, 0].values.tolist()
            IdAll+=[id]*len(dates)
            datesAll+=dates

        df = pd.DataFrame(list(zip(datesAll, IdAll,QirrAll,QcrsAll,QprivateAll)),
                          columns=['DoY','wsid','Qirr','Qcrs','Qprivate'])

        return df


if __name__ == '__main__':
    # nodeDF, linkDF,QirrDF,QCrsDF,QPrivateDF
    data = [[1,11,1],
            [2,3,0],
            [3,13,1],
            [4,14,0]]
    nodesDF = pd.DataFrame.from_records(data, columns=['id', 'node_type', 'q_sum'])
    nodesDF['id'] = nodesDF['id'].astype(int, errors='ignore')
    nodesDF['node_type'] = nodesDF['node_type'].astype(int, errors='ignore')

    distrEffDict = {'2':0.8}

    data = [[1,2,1.,0.2],
            [3,2,1.,0.1],
            [4,2,1.,0.1]]
    linksDF = pd.DataFrame.from_records(data, columns=['inlet_node','outlet_node','flow_rate','inf_losses'])
    linksDF['inlet_node'] = linksDF['inlet_node'].astype(int, errors='ignore')
    linksDF['outlet_node'] = linksDF['outlet_node'].astype(int, errors='ignore')

    data = [[52, 0.3],
            [53, 0.5],
            [54, 0.7],
            [55, 1.2]
            ]
    QirrDF = pd.DataFrame.from_records(data, columns=['doy','Source_'+str(2)])

    data = [[52, 0.0],
            [53, 3.0],
            [54, 3.0],
            [55, 0.0]
            ]
    QCrsDF = pd.DataFrame.from_records(data, columns=['doy', str(3)])

    data = [[52, 0.0],
            [53, 8.0],
            [54, 8.0],
            [55, 0.0]
            ]
    QPrivateDF = pd.DataFrame.from_records(data, columns=['doy', 'Source_' + str(2)])

    NA = NetworkAnalyst()
    NA.buildNetwork(nodesDF, linksDF,4)
    watDistrList = NA.updateDischargeWeights(QirrDF,QPrivateDF,QCrsDF,distrEffDict)
    NA.calculateFlowAtNodes(watDistrList,QCrsDF)
    res = NA.getFlowAtNodes(QPrivateDF['doy'].values.tolist())
    res['Qsum']=res['Qirr']+res['Qcrs']+res['Qprivate']
    print('res\n',res)
